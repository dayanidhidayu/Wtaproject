<?php
session_start();

  $_SESSION['usernamesession']=NULL;
                            $_SESSION['passwordsession']=NULL;
echo "<meta http-equiv=\"refresh\" content=\"0;adminlogin.php\">";
?>
