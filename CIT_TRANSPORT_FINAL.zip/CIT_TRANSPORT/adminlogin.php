<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <!--[if IE]><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"><![endif]-->
    <!--<meta name="viewport" content="width=device-width, initial-scale=1.0">-->
    <!-- 
    Dragonfruit Template 
    http://www.templatemo.com/preview/templatemo_411_dragonfruit 
    -->
    <title>LOGIN</title>
    <meta name="description" content="" />
    <!-- templatemo 411 dragonfruit -->
    <meta name="author" content="templatemo">
    <!-- Favicon-->
    <link rel="shortcut icon" href="./favicon.png" />		
    <!-- Font Awesome -->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Camera -->
    <link href="css/camera.css" rel="stylesheet">
    <!-- Template  -->
    <link href="css/templatemo_style.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	<style>
	
	.formbox 
	{
 align: center;
  background-color: #f2f2e5;
 width: 520px;
  padding: 20px;
  margin: 20px;
  
}
	
	
input[type=submit] {
    width: 8%;
	
    background-color: #333333;
    color: #fff;
    padding: 10px 60px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
	text-align:center;
	
}


input[type=submit]:hover {
    background-color: #45a049;
}


button[type=submit] {
    width: 8%;
	
    background-color: #333333;
    color: #fff;
    padding: 10px 70px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
		text-align:center;

	
}


button[type=submit]:hover {
    background-color: #45a049;
}


select {
    width: 8%;
	 background-color: white;
    
    color: black;
    padding: 14px 120px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
	
}
#one{
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
}

h5{

    
	 color:black;
}
h6{

    
	 color:white;
}
table {
position:absolute;
top:150px;
left:150px;

	width:80%;
   
}
button {
 background-color: #333333;
    width: 100%;
	color:white;
    padding: 12px 20px;
    margin: 8px 0;
    box-sizing: border-box;
	border: 2px solid #66605E;
}
input[type=text] {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    box-sizing: border-box;
	border: 2px solid #66605E;
}
input[type=password] {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    box-sizing: border-box;
	border: 2px solid #66605E;
}
td, th {
  background-color: black;
  color:white;
    border: 1px solid white;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
 color:white;
    background-color: white;
}
	</style>
  </head>
<body>
<div  class="banner" id="templatemo_banner_slide">
    <ul>
        <li class="templatemo_banner_slide_01">
          <br><br><br>
		  
		   <h2 style="color:black; position:absolute; top:80px; left:500px;">LOGIN</h2>
		   <div>
          <form method="post" style="color:black; position:absolute; top:112px; left:510px;" class="formbox">
    <h5> <label for="fname">USER NAME:</label></h5>
    <input type="text" id="fname" name="username" placeholder="Your name..">
<br>
    <h5><label for="lname">PASSWORD:</label></h5>
    <input type="password" id="lname" name="password" placeholder="Your password..">

   <br>
  
    <input type="submit" value="LOGIN">
  </form>
  
   <form method="post" action="register.php" style="color:black; position:absolute; top:360px; left:680px;" >
    <button type="submit" id="submit">REGISTER</button>
  </form>
</div>
</div>

		<?php
                    include 'dbconfig.php';
                    session_start();
                    if(isset($_POST["username"])&&isset($_POST["password"])){
                    $username=$_POST["username"];
                    $password=$_POST["password"];
					
						   $sql1= "select * from register where username='$username' and password='$password'";
                    $result1=  mysqli_query($conn, $sql1);
					
                    $sql= "select * from admin where username='$username' and password='$password'";
                    $result=  mysqli_query($conn, $sql);
				
					
						  $row1= mysqli_fetch_array($result1,MYSQLI_ASSOC);
                    $dbname11=$row1['username'];
                    $dbpassword1=$row1['password'];
					
                    $row= mysqli_fetch_array($result,MYSQLI_ASSOC);
                    $dbname1=$row['username'];
                    $dbpassword=$row['password'];
                    
                    
				
					
					
                    
                    if($username==$dbname11 && $password==$dbpassword1){
                        $_SESSION['usernamesession']=$username;
                            $_SESSION['passwordsession']=$password;
                        echo "<meta http-equiv=\"refresh\" content=\"0;index.php\">";
                        
                    }
					  else  if($username==$dbname1 && $password==$dbpassword){
                        $_SESSION['usernamesession1']=$username;
                            $_SESSION['passwordsession1']=$password;
                        echo "<meta http-equiv=\"refresh\" content=\"0;busdetails.php\">";
						
                        
                    }
 else {
     echo " <script type=\"text/javascript\" >alert(\"username or password incorrect\") </script>";
 }
                    }
                    
                    ?>

	  
	  
	  
            
        </li>
        
    </ul>
</div>


<div class="container_wapper">
    <div id="templatemo_banner_menu">
        <div class="container-fluid">
            <div class="col-xs-4 templatemo_logo">
            	<a href="#">
                	<img src="images/logo.png" id="logo_img"  />
                
                </a>
            </div>
            
            <div class="col-xs-8 visible-xs">
                <a href="#" id="mobile_menu"><span class="glyphicon glyphicon-th-list"></span></a>
            </div>
        </div>
    </div>
</div>
 <br><br>
		   
      

<div id="templatemo_footer">
    <div>
        <p id="footer">Developed By: DAYANIDHI R S, VAISHNAVI S, INDIRA K M</p>
    </div>
</div>
<script src="js/jquery.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.singlePageNav.min.js"></script>
<script src="js/unslider.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&amp;sensor=false"></script>
<script src="js/templatemo_script.js"></script>
</body>
</html>