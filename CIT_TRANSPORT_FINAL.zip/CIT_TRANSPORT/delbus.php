<?php
                 include 'dbconfig.php';

     
           $busno=$_GET['id'];
       
     
           $sql = "delete from  `busdetails` where `busno`='$busno' ";
                     if(mysqli_query($conn, $sql))
                    {
                            
                            echo "<script type=\"text/javascript\">alert(\"Bus deleted\");</script>";
                            echo "<meta http-equiv=\"refresh\" content=\"0;updatebus.php\">";  
                     }
               
                             
                
                else
               {
                   echo '<span style="color:red;">Deletion Unsuccesful</a></span>';
               }
       
     
        ?>  
