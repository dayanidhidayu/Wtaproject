<!DOCTYPE html>
<?php
session_start();
if(isset($_SESSION['usernamesession']) && isset($_SESSION['passwordsession'])){
    $user=$_SESSION['usernamesession'];
    $pass=$_SESSION['passwordsession'];
    
}
 else {
  echo "<meta http-equiv=\"refresh\" content=\"0;logout.php\">";  
 }



 

?>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <!--[if IE]><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"><![endif]-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- 
    Dragonfruit Template 
    http://www.templatemo.com/preview/templatemo_411_dragonfruit 
    -->
    <title>bus</title>
    <meta name="description" content="" />
    <!-- templatemo 411 dragonfruit -->
    <meta name="author" content="templatemo">
    <!-- Favicon-->
    <link rel="shortcut icon" href="./favicon.png" />		
    <!-- Font Awesome -->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Camera -->
    <link href="css/camera.css" rel="stylesheet">
    <!-- Template  -->
    <link href="css/templatemo_style.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	<style>
	
	.formbox 
	{
 align: center;
  background-color: #f2f2e5;
 width: 520px;
  padding: 20px;
  margin: 20px;
  
}
	input[type=submit] {
    width: 8%;
	
    background-color: #333333;
    color: #fff;
    padding: 14px 60px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
	
}
select {
    width: 8%;
	 background-color: white;
    
    color: black;
    padding: 14px 120px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
	
}
#one{
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
}

h5{

    
	 color:black;
}
h6{

    
	 color:white;
}
table {
  border-collapse: collapse;
  position:absolute;
top:150px;
left:150px;

	width:80%;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}
tr:nth-child(odd){background-color: #f2f2f2}
th {
  background-color: #858383;
  color: white;
}
button {
 background-color: #333333;
    width: 100%;
	color:white;
    padding: 12px 20px;
    margin: 8px 0;
    box-sizing: border-box;
	border: 2px solid #66605E;
}
	</style>
  </head>
<body>
<div  class="banner" id="templatemo_banner_slide">
    <ul>
        <li class="templatemo_banner_slide_01">
          <br><br><br>
           <h2 style="color:black; position:absolute; top:80px; left:150px;">Bus Details</h2>
	<?php
                            include("dbconfig.php");
                           $sql = " select * from `busdetails` ";
                               $result = $conn->query($sql);
                               
                               if ($result->num_rows > 0){
                                                                        echo"  <table>";

         echo " <tr> ";
		    echo " <th><h3>Bus number</h3></th> ";
           echo " <th><h3>Driver Name</h3></th> ";
           echo " <th><h3>Route Name</h3></th> ";
           
           
       echo " </tr> ";
                                   
                                   while($row = $result->fetch_assoc()) {
                                       $busno=$row["busno"];
                                       $dname=$row["dname"];
                                       $rname=$row["rname"];
                                      

  
          if($busno>0){
   
          
         echo "   <td><h3>$busno</h3></td> ";
         echo "   <td><h3>$dname</h3></td> ";
         echo "   <td><h3>$rname</h3></td> ";

       echo " </tr> ";
  
		 
		  }                             
                                       
                                       
                                
                              }
                                                                   echo"  </table>";


                        $conn->close();    
                }
                                   
                             
                            
                            
          ?>
            
        </li>
        
    </ul>
	 <form method="post" action="logout.php" style="color:black; position:absolute; top:30px; right:30px;" >
    <button type="submit" id="submit">LOGOUT</button>
  </form>
</div>
  
<div id="templatemo_mobile_menu">
        <ul class="nav nav-pills nav-stacked">
            <li><a rel="nofollow" href="index.php" class="external-link"><i class="glyphicon glyphicon-export"></i> &nbsp;  SEARCH</a></li>
            <li><a rel="nofollow" href="bus.php" class="external-link"><i class="glyphicon glyphicon-export"></i> &nbsp; BUS DETAILS</a></li>
            <li><a rel="nofollow" href="route.php" class="external-link"><i class="glyphicon glyphicon-export"></i> &nbsp; ROUTE DETAILS</a></li>
            <li><a rel="nofollow" href="driver.php" class="external-link"><i class="glyphicon glyphicon-export"></i> &nbsp; DRIVER DETAILS</a></li>
            <li><a rel="nofollow" href="complaint.php" class="external-link"><i class="glyphicon glyphicon-export"></i> &nbsp; COMPLAINT</a></li>
         
        </ul>
</div>
<div class="container_wapper">
    <div id="templatemo_banner_menu">
        <div class="container-fluid">
            <div class="col-xs-4 templatemo_logo">
            	<a href="#">
                	<img src="images/logo.png" id="logo_img"  />
                
                </a>
            </div>
            <div class="col-sm-8 hidden-xs">
                <ul class="nav nav-justified">
                    <li><a rel="nofollow" href="index.php" class="external-link">SEARCH</a></li>
                    <li><a rel="nofollow" href="bus.php" class="external-link">BUS DETAILS</a></li>
                    <li><a  rel="nofollow" href="route.php" class="external-link">ROUTE DETAILS</a></li>
                    <li><a rel="nofollow" href="driver.php" class="external-link">DRIVER DETAILS</a></li>
                    <li><a rel="nofollow" href="complaint.php" class="external-link"> COMPLAINT</a></li>
                   
                 </ul>
            </div>
            <div class="col-xs-8 visible-xs">
                <a href="#" id="mobile_menu"><span class="glyphicon glyphicon-th-list"></span></a>
            </div>
        </div>
    </div>
</div>
 <br><br>
		   
      

<div id="templatemo_footer">
    <div>
        <p id="footer"> Developed By: DAYANIDHI R S, VAISHNAVI S, INDIRA K M</p>
    </div>
</div>
<script src="js/jquery.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.singlePageNav.min.js"></script>
<script src="js/unslider.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&amp;sensor=false"></script>
<script src="js/templatemo_script.js"></script>
</body>
</html>