<?php
$servername = "127.0.0.1";
$user = "root";
$password = "";
$dbname ="CITBUS";
$conn = new mysqli($servername, $user , $password , $dbname);
?>