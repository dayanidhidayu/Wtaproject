<?php
                 include 'dbconfig.php';

     
           $cid=$_GET['id'];
       
          $query1="select * from complaint";
	 if ($cid!=$query1)
	 {

           $sql = "delete from  `complaint` where `cid`='$cid' ";
                     if(mysqli_query($conn, $sql))
                    {
                            
                            echo "<script type=\"text/javascript\">alert(\"ACTION REGISTERED\");</script>";
                            echo "<meta http-equiv=\"refresh\" content=\"0;viewcomplaint.php\">";  
                     }
	 
                             
                
                else
               {
                   echo "<script type=\"text/javascript\">alert(\"COMAPLAINT CANNOT BE DELETED \");</script>";
                            echo "<meta http-equiv=\"refresh\" content=\"0;viewcomplaint.php\">";
               }
       }
	   else
               {
                   echo '<span style="color:red;">NO ACTION TAKEN</a></span>';
               }
     
        ?>  
