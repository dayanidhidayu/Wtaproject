<?php
                 include 'dbconfig.php';

     
           $rnum=$_GET['id'];
       
           $sql = "delete from  `route` where `rnum`='$rnum' ";
                     if(mysqli_query($conn, $sql))
                    {
                            
                            echo "<script type=\"text/javascript\">alert(\"Route deleted\");</script>";
                            echo "<meta http-equiv=\"refresh\" content=\"0;updateroute.php\">";  
                     }
               
                             
                
                else
               {
                   echo '<span style="color:red;">Deletion Unsuccesful</a></span>';
               }
       
     
        ?>  
