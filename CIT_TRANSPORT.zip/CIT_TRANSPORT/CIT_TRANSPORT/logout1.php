<?php
session_start();

  $_SESSION['usernamesession1']=NULL;
                            $_SESSION['passwordsession1']=NULL;
echo "<meta http-equiv=\"refresh\" content=\"0;adminlogin.php\">";
?>
