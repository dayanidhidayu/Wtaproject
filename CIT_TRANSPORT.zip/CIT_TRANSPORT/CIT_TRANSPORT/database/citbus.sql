-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 01, 2019 at 11:14 AM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.5.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `citbus`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', 123456);

-- --------------------------------------------------------

--
-- Table structure for table `busdetails`
--

CREATE TABLE `busdetails` (
  `busno` int(100) NOT NULL,
  `dname` varchar(100) NOT NULL,
  `rname` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `busdetails`
--

INSERT INTO `busdetails` (`busno`, `dname`, `rname`) VALUES
(1, 'Lokesh', 'Jayanagar'),
(4, 'sudeep', 'Kyathasandra'),
(20, 'Rama', 'GObI CIRCLE');

-- --------------------------------------------------------

--
-- Table structure for table `circular`
--

CREATE TABLE `circular` (
  `cname` varchar(100) NOT NULL,
  `des` mediumtext NOT NULL,
  `busno` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `circular`
--

INSERT INTO `circular` (`cname`, `des`, `busno`) VALUES
('Bus delay', 'On 31-10-2019, Bus number 1 will be 10  min late.', 1),
('Bus delay', 'On 31-10-2019, Bus number 1 will be 10  min late.', 1);

-- --------------------------------------------------------

--
-- Table structure for table `complaint`
--

CREATE TABLE `complaint` (
  `cid` int(100) NOT NULL,
  `cname` varchar(100) NOT NULL,
  `des` varchar(1000) NOT NULL,
  `busno` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `driver`
--

CREATE TABLE `driver` (
  `dname` varchar(100) NOT NULL,
  `dphn` int(11) NOT NULL,
  `daddr` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `driver`
--

INSERT INTO `driver` (`dname`, `dphn`, `daddr`) VALUES
('Jake', 2147483647, 'Brooklyn'),
('Lokesh', 12454567, 'Tumkur'),
('Rama', 994569885, 'ss puram'),
('Rocky', 1234567892, 'KGF'),
('sudeep', 720419557, 'gandhi bazar, shivamogga');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `usn` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`username`, `email`, `usn`, `password`) VALUES
('rahul', 'rahull@gmail.com', '4pm1500000', 'pass'),
('vaishnavi.s', 'VAISHNAVI98@GMAIL.COM', '1CG16IS058', 'welcome');

-- --------------------------------------------------------

--
-- Table structure for table `route`
--

CREATE TABLE `route` (
  `rnum` int(20) NOT NULL,
  `rname` varchar(100) NOT NULL,
  `stploc` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `route`
--

INSERT INTO `route` (`rnum`, `rname`, `stploc`) VALUES
(1, 'Jayanagara', 'SMA Bakery'),
(2, 'GObI CIRCLE', 'C circle, DCC Bank, Tank Mohalla, KEB circle, Sheshadripura flyover , Reliance Petrol Bunk,Meenakshi Bavan, Krishna cafÃ©,Amir Ahemad Circle, Busstand, Alkola PESITM'),
(4, 'Kyathasandra', 'Mathaaaaaa'),
(12, 'BH road', 'SIT college');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `busdetails`
--
ALTER TABLE `busdetails`
  ADD PRIMARY KEY (`busno`),
  ADD UNIQUE KEY `dname` (`dname`);

--
-- Indexes for table `circular`
--
ALTER TABLE `circular`
  ADD KEY `busno` (`busno`);

--
-- Indexes for table `complaint`
--
ALTER TABLE `complaint`
  ADD PRIMARY KEY (`cid`),
  ADD KEY `busno` (`busno`);

--
-- Indexes for table `driver`
--
ALTER TABLE `driver`
  ADD PRIMARY KEY (`dname`);

--
-- Indexes for table `route`
--
ALTER TABLE `route`
  ADD PRIMARY KEY (`rnum`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `complaint`
--
ALTER TABLE `complaint`
  MODIFY `cid` int(100) NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `busdetails`
--
ALTER TABLE `busdetails`
  ADD CONSTRAINT `busdetails_ibfk_1` FOREIGN KEY (`dname`) REFERENCES `driver` (`dname`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `circular`
--
ALTER TABLE `circular`
  ADD CONSTRAINT `circular_ibfk_1` FOREIGN KEY (`busno`) REFERENCES `busdetails` (`busno`);

--
-- Constraints for table `complaint`
--
ALTER TABLE `complaint`
  ADD CONSTRAINT `complaint_ibfk_1` FOREIGN KEY (`busno`) REFERENCES `busdetails` (`busno`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
