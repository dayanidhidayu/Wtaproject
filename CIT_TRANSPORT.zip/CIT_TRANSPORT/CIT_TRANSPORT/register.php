<!DOCTYPE html>

<html lang="en">
  <head>
    <meta charset="utf-8">
    <!--[if IE]><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"><![endif]-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- 
    Dragonfruit Template 
    http://www.templatemo.com/preview/templatemo_411_dragonfruit 
    -->
    <title>register</title>
    <meta name="description" content="" />
    <!-- templatemo 411 dragonfruit -->
    <meta name="author" content="templatemo">
    <!-- Favicon-->
    <link rel="shortcut icon" href="./favicon.png" />		
    <!-- Font Awesome -->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Camera -->
    <link href="css/camera.css" rel="stylesheet">
    <!-- Template  -->
    <link href="css/templatemo_style.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	<style>
	
	.formbox 
	{
 align: center;
  background-color: #f2f2e5;
 width: 520px;
  padding: 20px;
  margin: 20px;
  
}
	
input[type=submit] {
    width: 8%;
	
    background-color: #333333;
    color: #fff;
    padding: 19px 60px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
	text-align:center;
	
}


input[type=submit]:hover {
    background-color: #45a049;
}


button[type=submit] {
    width: 8%;
	
    background-color: #333333;
    color: #fff;
    padding: 19px 70px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
		text-align:center;

	
}


button[type=submit]:hover {
    background-color: #45a049;
}


select {
    width: 8%;
	 background-color: white;
    
    color: black;
    padding: 14px 120px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
	
}
#one{
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
}

h5{

    
	 color:black;
}
h6{

    
	 color:white;
}
table {
position:absolute;
top:150px;
left:150px;

	width:80%;
   
}
input[type=text] {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    box-sizing: border-box;
	border: 2px solid #66605E;
}
input[type=email] {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    box-sizing: border-box;
	border: 2px solid #66605E;
}
input[type=password] {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    box-sizing: border-box;
	border: 2px solid #66605E;
}
td, th {
  background-color: black;
  color:white;
    border: 1px solid white;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
 color:white;
    background-color: white;
}
	</style>
  </head>
<body>
<div  class="banner" id="templatemo_banner_slide">
    <ul>
        <li class="templatemo_banner_slide_01">
          <br><br><br>
		  
		   <h2 style="color:black; position:absolute; top:1px; left:280px;">REGISTER</h2>
          <form method="post" style="color:black; position:absolute; top:0px; left:500px;" class="formbox">
    <h5> <label for="fname">USERNAME:</label></h5>
    <input type="text" id="fname" name="username" placeholder="Your name..">
<br><h5><label for="lname">EMAIL ID:</label></h5>
    <input type="email" id="lname" name="email" placeholder="Your emailid..">

   <h5><label for="lname">USN:</label></h5>
    <input type="text" id="lname" name="usn" placeholder="Your usn..">

 
    <h5><label for="lname">PASSWORD:</label></h5>
    <input type="password" id="lname" name="password" placeholder="Your password..">

   <br>
  
    <input type="submit" value="SIGNUP">
	<a href="adminlogin.php" style="color:black; display:bold;">&nbsp;&nbsp;IF REGISTERED CLICK HERE</a>
  </form>
</div>

		 <?php
                 include 'dbconfig.php';

       if (isset($_POST['username']) && isset ($_POST['email']) && isset ($_POST['password']) && isset ($_POST['usn'])){
           $username=$_POST['username'];
           $email=$_POST['email'];
           $password=$_POST['password'];
		      $usn=$_POST['usn'];
           $sql = "INSERT INTO `register` (`username`, `email`, `usn`, `password`) VALUES ('$username','$email','$usn','$password')";
                     if(mysqli_query($conn, $sql))
                    {
                            
                            echo "<script type=\"text/javascript\">alert(\"Data Entered Successfully\");</script>";
                     }
               
                             
                
                else
               {
                   echo '<span style="color:red;">Insert all Attributes</a></span>';
               }
       }
     
        ?> 

	  
	  
	  
            
        </li>
        
    </ul>
</div>


<div class="container_wapper">
    <div id="templatemo_banner_menu">
        <div class="container-fluid">
            <div class="col-xs-4 templatemo_logo">
            	<a href="#">
                	<img src="images/logo.png" id="logo_img"  />
                
                </a>
            </div>
            
            <div class="col-xs-8 visible-xs">
                <a href="#" id="mobile_menu"><span class="glyphicon glyphicon-th-list"></span></a>
            </div>
        </div>
    </div>
</div>
 <br><br>
		   
      

<div id="templatemo_footer">
    <div>
        <p id="footer">Developed By: DAYANIDHI R S, VAISHNAVI S, INDIRA K M</p>
    </div>
</div>
<script src="js/jquery.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.singlePageNav.min.js"></script>
<script src="js/unslider.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&amp;sensor=false"></script>
<script src="js/templatemo_script.js"></script>
</body>
</html>