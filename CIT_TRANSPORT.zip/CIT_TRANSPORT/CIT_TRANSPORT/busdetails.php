



<!DOCTYPE html>
<?php
include './dbconfig.php';
session_start();
if(isset($_SESSION['usernamesession1']) && isset($_SESSION['passwordsession1'])){
    $user=$_SESSION['usernamesession1'];
    $pass=$_SESSION['passwordsession1'];
    
}
 else {
  echo "<meta http-equiv=\"refresh\" content=\"0;logout1.php\">";  
 }



 

?>












<html lang="en">
  <head>
  
  <script>
function Reg()
{
	var numpattern = /^\d{2}$/;
	var msg="";
	var busnumber=document.getElementById("busno").value;  
	//var usn=document.getElementById("usn").value;
	
	
	if(busnumber==undefined || busnumber=="")
		{
		msg="Bus Number cannot be blank";
		}
		
	// if(!(busnumber.match(numpattern)))
	     // {
	      // msg=msg+"\nBus Number should be a numeric value";
	     // }
		 
	if(msg!="")
		{
		alert(msg);
		return false;
		}
	//else
		//{
		//var details="Name: "+name+"<br>USN: "+usn+"<br>Gender: "+gender+"<br>Country: "+cou+"<br>State: "+st+"<br>City: "+ci+"<br>Hobbies: "+hobby+"<br>Branch: "+bran;
		//document.getElementById("print").innerHTML = details;
		//return false;
		//}	 
}	
</script>
    <meta charset="utf-8">
    <!--[if IE]><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"><![endif]-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- 
    Dragonfruit Template 
    http://www.templatemo.com/preview/templatemo_411_dragonfruit 
    -->
    <title>BUS DETAILS</title>
    <meta name="description" content="" />
    <!-- templatemo 411 dragonfruit -->
    <meta name="author" content="templatemo">
    <!-- Favicon-->
    <link rel="shortcut icon" href="./favicon.png" />		
    <!-- Font Awesome -->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Camera -->
    <link href="css/camera.css" rel="stylesheet">
    <!-- Template  -->
    <link href="css/templatemo_style.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	<style>
	
	.formbox 
	{
 align: center;
  background-color: #f2f2e5;
 width: 520px;
  padding: 20px;
  margin: 20px;
  
}
	
input[type=submit] {
    width: 8%;
	
    background-color: #333333;
    color: #fff;
    padding: 10px 60px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
	text-align:center;
	
}


input[type=submit]:hover {
    background-color: #45a049;
}


button[type=submit] {
    width: 8%;
	
    background-color: #333333;
    color: #fff;
    padding: 10px 120px 10px 50px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
 text-align:center;

	
}


button[type=submit]:hover {
    background-color: #45a049;
}


select {
    width: 8%;
	 background-color: white;
    
    color: black;
    padding: 14px 120px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
	
}
#one{
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
}

h5{

    
	 color:black;
}
h6{

    
	 color:white;
}

table {
  border-collapse: collapse;
  position:absolute;
top:150px;
left:150px;

	width:80%;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
  background-color: #858383;
  color: white;
}

input[type=text] {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    box-sizing: border-box;
	border: 2px solid #66605E;
}
input[type=number] {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    box-sizing: border-box;
	border: 2px solid #66605E;
}
button {
 background-color: #333333;
    width: 100%;
	color:white;
    padding: 12px 20px;
    margin: 8px 0;
    box-sizing: border-box;
	border: 2px solid #66605E;
}

	</style>
  </head>
<body>
<div  class="banner" id="templatemo_banner_slide">
    <ul>
        <li class="templatemo_banner_slide_01">
          <br><br><br>
           <h2 style="color:black; position:absolute; top:80px; left:500px;">ADD BUS DETAILS</h2>
	
		  
  <form method="post" style="color:black; position:absolute; top:150px; left:550px;" class="formbox">
    <h5> <label for="fname">BUS NUMBER:</label></h5>
    <input type="number" id="busno" name="busno" placeholder="Enter bus number..">
<br>


    <h5><label for="lname">DRIVER NAME:</label></h5>
	
	
	
<select class="form-control "name="dname">
                    <option value="">SELECT DRIVER</option>
					 <?php
                    $query="select dname,dphn from driver";
					
                    $run=$conn->prepare($query);
                    $run->execute();
                    $rs=$run->get_result();
                    while ($res=$rs->fetch_assoc()) {
						
                    ?>
					
                    <option value="<?php echo $res["dname"];?>"><?php echo $res['dname']; ?></option>
					 <?php }?>
					
                </select>

  <h5><label for="lname">ROUTE NAME:</label></h5>
  
  <select class="form-control" name="rname">
                    <option value="">SELECT ROUTE</option>
					 <?php
                    $query1="select * from route";
                    $run1=$conn->prepare($query1);
                    $run1->execute();
                    $rs1=$run1->get_result();
                    while ($res1=$rs1->fetch_assoc()) {
                    ?>
                    <option value="<?php echo $res1["rname"];?>"><?php echo $res1['rname']; ?></option>
                    <?php }?>
                </select>
 
	
    <input type="submit" value="Add" onclick="return Reg()" id="register">
	  

  </form>
  <form method="post" action="updatebus.php" style="color:black; position:absolute; top:451px; left:715px;">
    <button type="submit" id="submit">UPDATE/DELETE</button>
  </form>
  
    <form method="post" action="logout1.php" style="color:black; position:absolute; top:30px; right:30px;" >
    <button type="submit" id="submit">LOGOUT</button>
  </form>
  
  <?php
                 include 'dbconfig.php';

       if (isset($_POST['busno']) && isset ($_POST['dname']) && isset ($_POST['rname'])){
           $busno=$_POST['busno'];
           $date=$_POST['dname'];
           $rname=$_POST['rname'];
		   
           $sql = "INSERT INTO `busdetails` (`busno`, `dname`, `rname`) VALUES ('$busno','$date','$rname')";
                     if(mysqli_query($conn, $sql))
                    {
                            
                            echo "<script type=\"text/javascript\">alert(\"Data Entered Successfully\");</script>";
                     }
               
                             
                
                else
               {
                   echo '<span style="color:red;">Insert all Attributes</a></span>';
               }
       }
     
        ?> 
	  
	  
	  
            
        </li>
        
    </ul>
</div>

<div id="templatemo_mobile_menu">
        <ul class="nav nav-pills nav-stacked">
            <li><a rel="nofollow" href="index.php" class="external-link"><i class="glyphicon glyphicon-export"></i> &nbsp;  SEARCH</a></li>
            <li><a rel="nofollow" href="bus.php" class="external-link"><i class="glyphicon glyphicon-export"></i> &nbsp; BUS DETAILS</a></li>
            <li><a rel="nofollow" href="route.php" class="external-link"><i class="glyphicon glyphicon-export"></i> &nbsp; ROUTE DETAILS</a></li>
            <li><a rel="nofollow" href="driver.php" class="external-link"><i class="glyphicon glyphicon-export"></i> &nbsp; DRIVER DETAILS</a></li>
            <li><a rel="nofollow" href="complaint.php" class="external-link"><i class="glyphicon glyphicon-export"></i> &nbsp; COMPLAINT</a></li>
            <li><a rel="nofollow" href="gallery.php" class="external-link"><i class="glyphicon glyphicon-export"></i> &nbsp; GALLERY</a></li>
        </ul>
</div>
<div class="container_wapper">
    <div id="templatemo_banner_menu">
        <div class="container-fluid">
            <div class="col-xs-4 templatemo_logo">
            	<a href="#">
                	<img src="images/logo.png" id="logo_img"  />
                
                </a>
            </div>
            <div class="col-sm-8 hidden-xs">
                <ul class="nav nav-justified">
                   
                    <li><a  href="busdetails.php" class="external-link">BUS DETAILS</a></li>
                    <li><a  href="routedetails.php" class="external-link">ROUTE DETAILS</a></li>
                    <li><a rel="nofollow" href="driverdetails.php" class="external-link">DRIVER DETAILS</a></li>
                    <li><a  href="viewcomplaint.php" class="external-link">VIEW COMPLAINT</a></li>
                    <li><a  href="circular.php" class="external-link">CIRCULAR</a></li>
                 </ul>
            </div>
            <div class="col-xs-8 visible-xs">
                <a href="#" id="mobile_menu"><span class="glyphicon glyphicon-th-list"></span></a>
            </div>
        </div>
    </div>
</div>
 <br><br>
		   
      

<div id="templatemo_footer">
    <div>
        <p id="footer"> Developed By: Dayanidhi R S, Vaishnavi S, Indira K M</p>
    </div>
</div>
<script src="js/jquery.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.singlePageNav.min.js"></script>
<script src="js/unslider.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&amp;sensor=false"></script>
<script src="js/templatemo_script.js"></script>
</body>
</html>